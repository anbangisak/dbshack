# from input import input_db_details, output_db_details
import Transform as tfm
import Load as load
import pyodbc
import Extract as ext
# import TweetExtract as twt
import sqlite3


def getConnectionODBC(driver, input_db_details=None):
    conn_str = (
        driver + ";"
        "DATABASE=dbs;"
        "UID=root;"
        "PWD=mysql;"
        "SERVER=52.70.237.253;"
        "PORT=3306;"
    )
    error = ''
    try:
        conn = pyodbc.connect(conn_str)
    except pyodbc.Error as err:
        error = 'ERROR'
        conn = err
    return error, conn

def initiateConnection(config_details, type):
    conn = '';
    error = '';

    if (config_details['dbtype'] == 'my_sql'):
        driver = 'DRIVER={MySQL ODBC 8.0 ANSI Driver}'
        error, conn = getConnectionODBC(driver, config_details)


    return error, conn;

def startExtract(conn):
    if (input_db_details['dbtype'] == 'csv'):
        rows = ext.processExtractCSV(input_db_details['csvloc'])
        dataDFList = ['csv', rows]


    return dataDFList

def main():
    error, conn = initiateConnection(input_db_details, 'i')

    if (error == 'ERROR'):
        print('ALERT....'+ str(conn))
        return;

    print('---> Starting Extratcing Process')
    dataDFList = startExtract(conn)

    print('---> Starting Transform Process')
    dataDFListTransform = tfm.processTransform(dataDFList);

    print('---> Starting Load Process')
    error, connL = initiateConnection(output_db_details, 'o')
    if (error == 'ERROR'):
        print('ALERT....' + str(conn))
        return;

    if (output_db_details['dbtype'] == 'csv'):
        load.loadProcessCsv(output_db_details['csvloc'],dataDFListTransform)


if __name__ == "__main__":
    main()
